// Single source of truth for every image on the site.
// Components import from here and never hardcode a path.
// Decorative images keep alt: "" (render them with aria-hidden).
// Flip an element in CSS (transform: scaleX(-1)) instead of making a second file:
//   bananaLeavesLeft -> top-right corner, pillar -> right-hand pillar.

export type Asset = { src: string; width: number; height: number; alt: string };

export const assets = {
  bgHeroParchment: { src: "/bg/hero-parchment.jpg", width: 944, height: 1680, alt: "" },
  bgTealSilk: { src: "/bg/teal-silk.jpg", width: 944, height: 1680, alt: "" },
  bgTealLinen: { src: "/bg/teal-linen.jpg", width: 944, height: 1680, alt: "" },
  bgTerracotta: { src: "/bg/terracotta.jpg", width: 944, height: 1680, alt: "" },
  bgBananaLeafPanel: { src: "/bg/banana-leaf-panel.png", width: 1024, height: 1536, alt: "" },
  framePillar: { src: "/frame/pillar.png", width: 896, height: 1776, alt: "" },
  frameBorder: { src: "/frame/border.png", width: 944, height: 1680, alt: "" },
  elementsLampHanging: { src: "/elements/lamp-hanging.png", width: 944, height: 1680, alt: "" },
  elementsGarlandBell: { src: "/elements/garland-bell.png", width: 944, height: 1680, alt: "" },
  elementsGopuram: { src: "/elements/gopuram.png", width: 1088, height: 1456, alt: "Temple gopuram" },
  elementsLotusCluster: { src: "/elements/lotus-cluster.png", width: 1456, height: 1088, alt: "" },
  elementsLotusSingle: { src: "/elements/lotus-single.png", width: 800, height: 800, alt: "" },
  elementsBananaLeavesLeft: { src: "/elements/banana-leaves-left.png", width: 1264, height: 1264, alt: "" },
  elementsFloorLamp: { src: "/elements/floor-lamp.png", width: 944, height: 1680, alt: "" },
  elementsBellsPair: { src: "/elements/bells-pair.png", width: 896, height: 1776, alt: "" },
  elementsKolamKnot: { src: "/elements/kolam-knot.png", width: 640, height: 640, alt: "" },
  elementsBowlTurmeric: { src: "/elements/bowl-turmeric.png", width: 640, height: 640, alt: "" },
  elementsBowlKumkum: { src: "/elements/bowl-kumkum.png", width: 640, height: 640, alt: "" },
  elementsSugarcane: { src: "/elements/sugarcane.png", width: 896, height: 1776, alt: "" },
  elementsJasmineStrand: { src: "/elements/jasmine-strand.png", width: 896, height: 1776, alt: "" },
  petalsJasmine: { src: "/petals/jasmine.png", width: 256, height: 256, alt: "" },
  petalsMarigold: { src: "/petals/marigold.png", width: 256, height: 256, alt: "" },
  petalsLotusPetal: { src: "/petals/lotus-petal.png", width: 256, height: 256, alt: "" },
  sealWaxSeal: { src: "/seal/wax-seal.png", width: 640, height: 640, alt: "D and N monogram wax seal" },
  transitionsSilkDrape: { src: "/transitions/silk-drape.png", width: 944, height: 1680, alt: "" },
  transitionsLeafSweep: { src: "/transitions/leaf-sweep.png", width: 1536, height: 1024, alt: "" },
} as const satisfies Record<string, Asset>;

export type AssetKey = keyof typeof assets;

// Not generated yet. Components should render a labelled placeholder
// (dashed gold outline + the name) until these files are added to /public.
export const missingAssets = [
  "transitions/jasmine-curtain.png",   // hanging jasmine strands, tileable horizontally
  "transitions/light-glow.png",        // gold radial glow (blend with mix-blend-mode: screen)
  "envelope/envelope.png",             // teal envelope for the opening animation
] as const;
